//set up the constants to be referenced in the action creators

export const ADD_PLAYER = 'ADD_PLAYER';
export const EDIT_PLAYER = 'EDIT_PLAYER';
export const UPDATE_NAME = 'UPDATE_NAME';
export const DELETE_PLAYER = 'DELETE_PLAYER';
export const BALANCE_TEAMS = 'BALANCE_TEAMS';
export const GENERATE_TEAM = 'GENERATE_TEAM';
export const RESET = 'RESET';
